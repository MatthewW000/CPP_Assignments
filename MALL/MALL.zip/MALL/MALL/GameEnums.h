#pragma once

// Enum for Jedi classes
enum JediClass {
    JediSentinel,
    JediKnight,
    JediConsular,
    JediShadow
};

//Enums for JediSpells
enum JediSpells {
    ForceShock,
    ForceWave,
    ForceBlast,
    ForceObliterate
};

//Enums for Items
enum ItemType {
    Holocron,
    HealthPotion,
    ManaPotion
};