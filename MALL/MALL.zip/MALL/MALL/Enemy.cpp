#include "Enemy.h"

Enemy::Enemy(int x, int y) : xPosition(x), yPosition(y), representation(' S ') {};
