#pragma once

#include "Enemy.h"
#include "Game.h"
#include "Item.h"
#include "Map.h"
#include "Player.h"
#include "Room.h"
#include "String.h"

#include <cstdlib>
#include <iostream>
#include <random>
#include <vector>
#include "String.h"
#include <windows.h>
#include <map>
using namespace std;

//function to allow operator overloading within String utility class;
std::ostream& operator<<(std::ostream& os, const String& str) {
    // Assuming you have a method CStr() that returns a const char* to the internal string data
    os << str.CStr();
    return os;
}

//Function for clearing screen allowing better UX:
void ClearScreen() {
    // System-dependent command to clear the console
#ifdef _WIN32
    system("CLS");
#else
    system("clear");
#endif
}


//function for better ux on jedi class to have enum displayed as string
String JediClassToString(JediClass jediClass) {
    switch (jediClass) {
    case JediSentinel:
        return "Jedi Sentinel";
    case JediKnight:
        return "Jedi Knight";
    case JediConsular:
        return "Jedi Consular";
    case JediShadow:
        return "Jedi Shadow";
    default:
        return "Unknown Class";
    }
}


int main()
{
    String nothing;
    // ASCII Art for "MALL"
    cout << R"(
 .      .     T h i s   i s   t h e   g a l a x y   o f   . . .             .
                     .              .       .                    .      .
.        .               .       .     .            .
   .           .        .                     .        .            .
             .               .    .          .              .   .         .
               _________________      ____         __________
 .       .    /                 |    /    \    .  |          \
     .       /    ______   _____| . /      \      |    ___    |     .     .
             \    \    |   |       /   /\   \     |   |___>   |
           .  \    \   |   |      /   /__\   \  . |         _/               .
 .     ________>    |  |   | .   /            \   |   |\    \_______    .
      |            /   |   |    /    ______    \  |   | \           |
      |___________/    |___|   /____/      \____\ |___|  \__________|    .
  .     ____    __  . _____   ____      .  __________   .  _________
       \    \  /  \  /    /  /    \       |          \    /         |      .
        \    \/    \/    /  /      \      |    ___    |  /    ______|  .
         \              /  /   /\   \ .   |   |___>   |  \    \
   .      \            /  /   /__\   \    |         _/.   \    \            +
           \    /\    /  /            \   |   |\    \______>    |   .
            \  /  \  /  /    ______    \  |   | \              /          .
 .       .   \/    \/  /____/      \____\ |___|  \____________/  LS
                               .                                        .
     .                           .         .               .                 .
                .                                   .            .                        
)" << endl;

    // Welcome Message
    cout << "Welcome to a galaxy far, far away, mortal." << endl;
    nothing.ReadFromConsole();
    ClearScreen();

    // Explaining instructions
    cout << "You are a new Jedi accepted into the order, your first job is to find a hollocron on the planet MALL" << endl;
    nothing.ReadFromConsole();

    Game game;
    game.Run();

    return 0;
}

